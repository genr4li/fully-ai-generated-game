import pygame
import math
import json
import os
import random
# Sound management class
class SoundManager:
    def __init__(self):
        self.sounds = {}
        self._load_sounds()
        
    def _load_sounds(self):
        """Load all sound files from the sounds directory"""
        sound_dir = os.path.join(os.path.dirname(__file__), "sound")
        if not os.path.exists(sound_dir):
            os.makedirs(sound_dir)
            print(f"Created sounds directory at {sound_dir}")
            return
            
        for file in os.listdir(sound_dir):
            if file.endswith(".wav"):
                sound_path = os.path.join(sound_dir, file)
                sound_name = os.path.splitext(file)[0]
                try:
                    self.sounds[sound_name] = pygame.mixer.Sound(sound_path)
                except Exception as e:
                    print(f"Failed to load sound {sound_name}: {e}")
                    
    def play(self, sound_name):
        """Play a sound by name"""
        if sound_name in self.sounds:
            self.sounds[sound_name].play()
        else:
            print(f"Sound not found: {sound_name}")
            
    def stop_all(self):
        """Stop all playing sounds"""
        pygame.mixer.stop()

# Constants
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
FOV = math.pi / 3  # 60 degrees field of view

# Pre-render the vignette effect
def create_vignette(width, height):
    """Create a pre-rendered vignette surface"""
    vignette = pygame.Surface((width, height))
    vignette.fill((255, 255, 255))  # Start with white
    
    # Create radial gradient
    for y in range(0, height, 2):
        for x in range(0, width, 2):
            # Calculate distance from center (0 to 1)
            dx = (x - width/2) / (width/2)
            dy = (y - height/2) / (height/2)
            dist = min(1.0, math.sqrt(dx*dx + dy*dy))
            # Stronger effect in corners
            brightness = int(255 * (1.0 - dist * dist * 0.6))
            # Fill 2x2 blocks for performance
            pygame.draw.rect(vignette, (brightness, brightness, brightness), (x, y, 2, 2))
    
    return vignette

# Pre-render scanline overlay
def create_scanlines(width, height):
    """Create a pre-rendered scanline overlay"""
    scanlines = pygame.Surface((width, height), pygame.SRCALPHA)
    for y in range(0, height, 2):
        pygame.draw.line(scanlines, (0, 0, 0, 30), (0, y), (width, y))
    return scanlines

# Initialize pre-rendered effects
vignette_overlay = None
scanline_overlay = None

def init_shader_effects(width, height):
    """Initialize shader effects"""
    global vignette_overlay, scanline_overlay
    vignette_overlay = create_vignette(width, height)
    scanline_overlay = create_scanlines(width, height)

def apply_shader_effects(surface, time):
    """Apply post-processing shader effects to the surface"""
    global vignette_overlay, scanline_overlay
    
    # Initialize effects if needed
    if vignette_overlay is None:
        init_shader_effects(*surface.get_size())
    
    # Create copy for modifications
    shader_surface = surface.copy()
    
    # Apply pre-rendered effects
    shader_surface.blit(vignette_overlay, (0, 0), special_flags=pygame.BLEND_MULT)
    shader_surface.blit(scanline_overlay, (0, 0))
    
    return shader_surface

# Initialize Pygame and create screen
pygame.init()
pygame.font.init()
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Raycaster")
# Start with mouse grabbed for look controls; we'll release it when showing menus
pygame.mouse.set_visible(False)
pygame.event.set_grab(True)

# Initialize shader effects
init_shader_effects(SCREEN_WIDTH, SCREEN_HEIGHT)
HALF_FOV = FOV / 2
RAYS = 80  # Further reduced rays for performance
STEP_ANGLE = FOV / RAYS
MAX_DEPTH = 800
# Player and projection tuning
PLAYER_SPEED = 0.06  # movement speed multiplier
PLAYER_RADIUS = 0.2  # collision radius (in map cells)
PROJECTION_SCALE = 0.6  # multiplier for projection height

# Menu and game settings
MIN_WALL_HEIGHT = 20  # Don't render very small wall slices

# Pre-render the vignette effect
def create_vignette(width, height):
    """Create a pre-rendered vignette surface"""
    vignette = pygame.Surface((width, height))
    vignette.fill((255, 255, 255))  # Start with white
    
    # Create radial gradient
    for y in range(0, height, 2):
        for x in range(0, width, 2):
            # Calculate distance from center (0 to 1)
            dx = (x - width/2) / (width/2)
            dy = (y - height/2) / (height/2)
            dist = min(1.0, math.sqrt(dx*dx + dy*dy))
            # Stronger effect in corners
            brightness = int(255 * (1.0 - dist * dist * 0.6))
            # Fill 2x2 blocks for performance
            pygame.draw.rect(vignette, (brightness, brightness, brightness), (x, y, 2, 2))
    
    return vignette

# Pre-render scanline overlay
def create_scanlines(width, height):
    """Create a pre-rendered scanline overlay"""
    scanlines = pygame.Surface((width, height), pygame.SRCALPHA)
    for y in range(0, height, 2):
        pygame.draw.line(scanlines, (0, 0, 0, 30), (0, y), (width, y))
    return scanlines

# Initialize pre-rendered effects
vignette_overlay = None
scanline_overlay = None

def init_shader_effects(width, height):
    """Initialize shader effects"""
    global vignette_overlay, scanline_overlay
    vignette_overlay = create_vignette(width, height)
    scanline_overlay = create_scanlines(width, height)

def apply_shader_effects(surface, time):
    """Apply post-processing shader effects to the surface"""
    global vignette_overlay, scanline_overlay
    
    # Initialize effects if needed
    if vignette_overlay is None:
        init_shader_effects(*surface.get_size())
    
    # Create copy for modifications
    shader_surface = surface.copy()
    
    # Apply pre-rendered effects
    shader_surface.blit(vignette_overlay, (0, 0), special_flags=pygame.BLEND_MULT)
    shader_surface.blit(scanline_overlay, (0, 0))
    
    return shader_surface

class GameState:
    def __init__(self):
        # Game state
        self.paused = False
        self.selected_option = 0
        self.last_tab = False
        self.shader_time = 0  # For shader effects
        
        # Menu animation state
        self.menu_offset = SCREEN_HEIGHT  # Start offscreen
        self.target_offset = SCREEN_HEIGHT
        self.menu_alpha = 0  # For fade effect
        self.target_alpha = 0
        self.settings_offset = SCREEN_WIDTH  # For settings slide
        self.target_settings_offset = SCREEN_WIDTH
        self.last_time = pygame.time.get_ticks()
        
        # Settings (with min/max values)
        self.settings = {
            'Quality': {
                'value': 2,
                'min': 0,
                'max': 2,
                'options': ['Low', 'Medium', 'High']
            },
            'FOV': {
                'value': 60,
                'min': 45,
                'max': 90,
                'step': 5
            },
            'Mouse Sensitivity': {
                'value': 0.003,
                'min': 0.001,
                'max': 0.01,
                'step': 0.001
            },
            'Mode7 Floor': {
                'value': True,
                'min': 0,
                'max': 1,
                'options': ['Off', 'On']
            },
            'Mode7 Ceiling': {
                'value': True,
                'min': 0,
                'max': 1,
                'options': ['Off', 'On']
            }
        }
        
        # Menu options
        self.menu_options = ['Resume', 'Settings', 'New Map', 'Exit']
        self.in_settings = False
        self.selected_setting = 0
        self.transitioning_map = False  # For map transition effect
        
        # Load saved settings if they exist
        self.load_settings()
        
    @property
    def quick_mode(self):
        return self.settings['Quality']['value'] == 0
        
    def get_quality_settings(self):
        """Get quality-dependent settings"""
        quality = self.settings['Quality']['value']
        if quality == 0:  # Low
            return {
                'ray_step': 4,  # Mode7 pixel step
                'mode7_step': 4,  # Mode7 pixel step
                'rays': 60,  # Number of vertical slices
                'mode7_spacing': 32  # Space between floor/ceiling rays
            }
        elif quality == 1:  # Medium
            return {
                'ray_step': 2,
                'mode7_step': 2,
                'rays': 120,
                'mode7_spacing': 16
            }
        else:  # High
            return {
                'ray_step': 1,
                'mode7_step': 1,
                'rays': 160,
                'mode7_spacing': 8
            }
            
    def get_fov(self):
        return math.radians(self.settings['FOV']['value'])
        
    def get_mouse_sensitivity(self):
        return self.settings['Mouse Sensitivity']['value']
        
    def next_menu_item(self):
        if self.in_settings:
            self.selected_setting = (self.selected_setting + 1) % len(self.settings)
        else:
            self.selected_option = (self.selected_option + 1) % len(self.menu_options)
            
    def prev_menu_item(self):
        if self.in_settings:
            self.selected_setting = (self.selected_setting - 1) % len(self.settings)
        else:
            self.selected_option = (self.selected_option - 1) % len(self.menu_options)
            
    def adjust_setting(self, direction):
        if not self.in_settings:
            return
            
        setting_name = list(self.settings.keys())[self.selected_setting]
        setting = self.settings[setting_name]
        
        if 'options' in setting:  # Discrete options
            current = setting['value']
            if direction > 0:
                setting['value'] = min(setting['max'], current + 1)
            else:
                setting['value'] = max(setting['min'], current - 1)
        else:  # Continuous value
            current = setting['value']
            if direction > 0:
                setting['value'] = min(setting['max'], current + setting['step'])
            else:
                setting['value'] = max(setting['min'], current - setting['step'])
        
        # Save settings whenever they are changed
        self.save_settings()
    
    def save_settings(self):
        """Save current settings to a JSON file"""
        settings_data = {}
        for name, setting in self.settings.items():
            settings_data[name] = {'value': setting['value']}
        
        settings_path = os.path.join(os.path.dirname(__file__), 'raycaster_settings.json')
        try:
            with open(settings_path, 'w') as f:
                json.dump(settings_data, f, indent=4)
        except Exception as e:
            print(f"Failed to save settings: {e}")
    
    def load_settings(self):
        """Load settings from JSON file if it exists"""
        settings_path = os.path.join(os.path.dirname(__file__), 'raycaster_settings.json')
        try:
            if os.path.exists(settings_path):
                with open(settings_path, 'r') as f:
                    settings_data = json.load(f)
                    for name, data in settings_data.items():
                        if name in self.settings:
                            # Ensure value is within bounds
                            value = data['value']
                            setting = self.settings[name]
                            value = max(setting['min'], min(setting['max'], value))
                            setting['value'] = value
        except Exception as e:
            print(f"Failed to load settings: {e}")

# Create game state
state = GameState()

# Pre-render sky gradient
sky_gradient = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
for y in range(SCREEN_HEIGHT):
    # Gradient from very dark to slightly lighter
    t = y / SCREEN_HEIGHT
    sky_color = (
        int(5 + t * 15),   # Almost black
        int(5 + t * 15),
        int(10 + t * 20)
    )
    pygame.draw.line(sky_gradient, sky_color, (0, y), (SCREEN_WIDTH, y))

# Menu colors and font settings
MENU_BG = (0, 0, 0, 180)
MENU_FG = (255, 255, 255)
MENU_SELECTED = (255, 255, 0)
menu_font = None  # Will be initialized with Pygame

# Initialize Pygame
pygame.init()
pygame.font.init()

# Constants
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
MAX_DEPTH = 800

# Initialize fonts
font = pygame.font.SysFont('Arial', 16)
menu_font = pygame.font.SysFont('Arial', 32)
setting_font = pygame.font.SysFont('Arial', 24)
show_fps = True

def get_menu_item_rect(i, text, is_settings=False):
    """Get the rectangle for a menu item for mouse detection"""
    if is_settings:
        x = SCREEN_WIDTH // 4
        y = SCREEN_HEIGHT // 4 + i * 50
        width = SCREEN_WIDTH // 2
        height = 40
    else:
        x = SCREEN_WIDTH // 4
        y = SCREEN_HEIGHT // 2 - len(state.menu_options) * 30 + i * 60
        width = SCREEN_WIDTH // 2
        height = 40
    return pygame.Rect(x, y, width, height)

class Player:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.z = 0.5  # Height off the ground
        self.angle = 0
        self.pitch = 0  # Vertical look angle
        self.movement_cooldown = 0  # For footstep sounds
        self.vertical_velocity = 0
        self.gravity = -9.81 * 0.05  # Scaled down gravity
        
    def move(self, forward, strafe):
        # Get current time for sound cooldown
        current_time = pygame.time.get_ticks()
        
        # Calculate movement vector
        dx = math.cos(self.angle) * forward + math.cos(self.angle + math.pi/2) * strafe
        dy = math.sin(self.angle) * forward + math.sin(self.angle + math.pi/2) * strafe

        # Only move and play sound if actually moving
        if abs(dx) > 0.001 or abs(dy) > 0.001:
            # Proposed new position
            new_x = self.x + dx * PLAYER_SPEED
            new_y = self.y + dy * PLAYER_SPEED

            # Axis-separated collision to allow sliding
            # Check Y move
            try:
                if game_map[int(new_y)][int(self.x)] == 0:
                    self.y = new_y
                else:
                    # blocked on Y
                    pass
            except Exception:
                # out of bounds -> ignore movement
                pass

            # Check X move
            try:
                if game_map[int(self.y)][int(new_x)] == 0:
                    self.x = new_x
                else:
                    # blocked on X
                    pass
            except Exception:
                pass

            # Play footstep sound with cooldown
            if current_time - self.movement_cooldown > 500:  # 500ms cooldown
                sound_manager.play('footstep')
                self.movement_cooldown = current_time
                self.movement_cooldown = current_time

# Initialize sound manager
sound_manager = SoundManager()

# Simple map (1 = wall, 0 = empty)
def generate_random_map(size=12, wall_density=0.28, seed=None):
    """Generate a random square map with a solid border.
    size: number of cells per side (>=5)
    wall_density: probability for interior cells to be walls
    """
    if seed is not None:
        rnd = random.Random(seed)
    else:
        rnd = random
    size = max(5, int(size))
    m = [[1] * size for _ in range(size)]
    for y in range(1, size - 1):
        for x in range(1, size - 1):
            m[y][x] = 1 if rnd.random() < wall_density else 0
    # Ensure at least one opening near the center for the player
    cx = size // 2
    cy = size // 2
    m[cy][cx] = 0
    m[cy][cx+1 if cx+1 < size-1 else cx-1] = 0
    return m

# Initial map
game_map = generate_random_map()

# Wall colors with more variation
WALL_COLORS = [
    (180, 180, 190),  # Light gray-blue
    (160, 160, 170),  # Darker gray-blue
]

# Fog settings
FOG_COLOR = (10, 10, 15)  # Dark blue-gray fog
FOG_START = 3.0  # Distance where fog begins
FOG_END = 10.0   # Distance where fog is maximum

# Create player
player = Player(2, 2)

# Game loop
clock = pygame.time.Clock()
running = True

while running:
    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            # If paused, allow clicking menu items
            if state.paused and event.button == 1:
                pos = event.pos
                # If in settings screen, handle clicks on settings entries
                if state.in_settings:
                    for i, (name, setting) in enumerate(state.settings.items()):
                        rect = get_menu_item_rect(i, name, is_settings=True)
                        if rect.collidepoint(pos):
                            # click left half -> decrease, right half -> increase
                            if pos[0] < rect.centerx:
                                state.adjust_setting(-1)
                            else:
                                state.adjust_setting(1)
                            break
                else:
                    for i, opt in enumerate(state.menu_options):
                        rect = get_menu_item_rect(i, opt)
                        if rect.collidepoint(pos):
                            # Activate the option (reuse keyboard selection behavior)
                            state.selected_option = i
                            sel = state.menu_options[state.selected_option]
                            if sel == 'Resume':
                                state.paused = False
                                pygame.mouse.get_rel()
                                pygame.mouse.set_visible(False)
                                pygame.event.set_grab(True)
                            elif sel == 'Settings':
                                state.in_settings = not state.in_settings
                                # reset selected setting index
                                state.selected_setting = 0
                            elif sel == 'New Map':
                                # generate a new random map and place the player
                                new_map = generate_random_map()
                                game_map[:] = new_map
                                # find an empty cell near center
                                found = False
                                for oy in range(len(game_map)):
                                    for ox in range(len(game_map[0])):
                                        if game_map[oy][ox] == 0:
                                            player.x = ox + 0.5
                                            player.y = oy + 0.5
                                            player.angle = 0
                                            found = True
                                            break
                                    if found:
                                        break
                            elif sel == 'Exit':
                                running = False
                            break
            # Not paused -> gameplay click (shoot)
            elif event.button == 1 and not state.paused:
                sound_manager.play('shot')
        elif event.type == pygame.MOUSEMOTION:
            # Update hover selection while paused
            if state.paused:
                pos = event.pos
                if state.in_settings:
                    for i, (name, setting) in enumerate(state.settings.items()):
                        rect = get_menu_item_rect(i, name, is_settings=True)
                        if rect.collidepoint(pos):
                            state.selected_setting = i
                            break
                else:
                    for i, opt in enumerate(state.menu_options):
                        rect = get_menu_item_rect(i, opt)
                        if rect.collidepoint(pos):
                            state.selected_option = i
                            break
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_TAB:
                # Toggle pause/menu
                state.paused = not state.paused
                if state.paused:
                    pygame.mouse.set_visible(True)
                    pygame.event.set_grab(False)
                else:
                    # Resume gameplay: hide cursor and grab mouse
                    pygame.mouse.get_rel()  # reset relative movement
                    pygame.mouse.set_visible(False)
                    pygame.event.set_grab(True)
            # Menu navigation when paused
            if state.paused:
                # If we're inside settings, navigate settings entries
                if state.in_settings:
                    if event.key == pygame.K_UP:
                        state.selected_setting = (state.selected_setting - 1) % len(state.settings)
                    elif event.key == pygame.K_DOWN:
                        state.selected_setting = (state.selected_setting + 1) % len(state.settings)
                    elif event.key == pygame.K_LEFT:
                        state.adjust_setting(-1)
                    elif event.key == pygame.K_RIGHT:
                        state.adjust_setting(1)
                    elif event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                        # toggle discrete options (e.g., Quality)
                        state.adjust_setting(1)
                    elif event.key == pygame.K_ESCAPE:
                        state.in_settings = False
                else:
                    if event.key == pygame.K_UP:
                        state.selected_option = (state.selected_option - 1) % len(state.menu_options)
                    elif event.key == pygame.K_DOWN:
                        state.selected_option = (state.selected_option + 1) % len(state.menu_options)
                    elif event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                        sel = state.menu_options[state.selected_option]
                        if sel == 'Resume':
                            state.paused = False
                            pygame.mouse.get_rel()
                            pygame.mouse.set_visible(False)
                            pygame.event.set_grab(True)
                        elif sel == 'Settings':
                            state.in_settings = not state.in_settings
                            state.selected_setting = 0
                        elif sel == 'New Map':
                            new_map = generate_random_map()
                            game_map[:] = new_map
                            # place player
                            placed = False
                            for oy in range(len(game_map)):
                                for ox in range(len(game_map[0])):
                                    if game_map[oy][ox] == 0:
                                        player.x = ox + 0.5
                                        player.y = oy + 0.5
                                        player.angle = 0
                                        placed = True
                                        break
                                if placed:
                                    break
                        elif sel == 'Exit':
                            running = False
                    elif event.key == pygame.K_ESCAPE:
                        # Close menu
                        state.paused = False
                        pygame.mouse.get_rel()
                        pygame.mouse.set_visible(False)
                        pygame.event.set_grab(True)

    # Get keyboard input
    keys = pygame.key.get_pressed()
    forward = keys[pygame.K_w] - keys[pygame.K_s]
    strafe = keys[pygame.K_d] - keys[pygame.K_a]
    # If paused, block movement
    if state.paused:
        forward = 0
        strafe = 0

    # Update player
    player.move(forward, strafe)

    # Look around with mouse
    if not state.paused:
        rel_x, rel_y = pygame.mouse.get_rel()
        player.angle += rel_x * state.get_mouse_sensitivity()
        player.pitch = max(-math.pi/3, min(math.pi/3, player.pitch - rel_y * state.get_mouse_sensitivity()))
        
        # Apply gravity and jumping
        player.vertical_velocity += player.gravity
        player.z += player.vertical_velocity
        
        # Ground collision
        if player.z < 0.5:
            player.z = 0.5
            player.vertical_velocity = 0
            
        # Jump if space is pressed and on ground
        if keys[pygame.K_SPACE] and player.z <= 0.5:
            player.vertical_velocity = 0.3

    # Draw sky gradient
    screen.blit(sky_gradient, (0, 0))
    
    # Calculate mode7 floor and ceiling if enabled
    if state.settings['Mode7 Floor']['value'] or state.settings['Mode7 Ceiling']['value']:
        # Get current FOV and quality settings
        fov = state.get_fov()
        half_fov = fov / 2
        quality = state.get_quality_settings()
        mode7_step = quality['mode7_step']
        mode7_spacing = quality['mode7_spacing']
        
        # Pre-calculate sine and cosine values
        sin_a = math.sin(player.angle)
        cos_a = math.cos(player.angle)
        
        # Calculate pitch-adjusted horizon line
        horizon = SCREEN_HEIGHT//2 + int(player.pitch * SCREEN_HEIGHT * 0.7)
        
        # Floor range: from horizon to bottom of screen
        if state.settings['Mode7 Floor']['value']:
            floor_start = min(SCREEN_HEIGHT - 1, max(0, horizon))
            floor_end = SCREEN_HEIGHT
        else:
            floor_start = floor_end = horizon
            
        # Ceiling range: from top of screen to horizon
        if state.settings['Mode7 Ceiling']['value']:
            ceiling_start = 0
            ceiling_end = max(0, min(SCREEN_HEIGHT - 1, horizon))
        else:
            ceiling_start = ceiling_end = 0
        
        # Render floor
        for screen_y in range(floor_start, floor_end, mode7_step):
            # Calculate row distance with perspective correction
            p = screen_y - horizon
            if abs(p) < 1: continue  # Skip horizon line
            
            # Adjust row distance based on height
            pos_z = player.z * SCREEN_HEIGHT * 0.5
            row_distance = pos_z / p
            
        # Render ceiling
        for screen_y in range(ceiling_end - 1, ceiling_start - 1, -mode7_step):
            p = screen_y - horizon
            if abs(p) < 1: continue  # Skip horizon line
            
            pos_z = (player.z - 1) * SCREEN_HEIGHT * 0.5  # Offset for ceiling
            row_distance = pos_z / p
            
            # Skip if too close or too far
            if abs(row_distance) < 0.1 or abs(row_distance) > 20: 
                continue
            # Ray direction in world space
            ray_dir_x0 = math.cos(player.angle - half_fov)
            ray_dir_y0 = math.sin(player.angle - half_fov)
            ray_dir_x1 = math.cos(player.angle + half_fov)
            ray_dir_y1 = math.sin(player.angle + half_fov)

            # Current y position compared to the center of the screen
            p = screen_y - SCREEN_HEIGHT/2
            
            # Vertical position of the camera
            pos_z = player.z * SCREEN_HEIGHT
            
            # Adjust for pitch
            row_distance = pos_z / p if p != 0 else float('inf')

            if row_distance < 0 and state.settings['Mode7 Ceiling']['value'] and screen_y < SCREEN_HEIGHT/2:
                # Draw ceiling
                floor_step_x = row_distance * (ray_dir_x1 - ray_dir_x0) / SCREEN_WIDTH
                floor_step_y = row_distance * (ray_dir_y1 - ray_dir_y0) / SCREEN_WIDTH

                floor_x = player.x + row_distance * ray_dir_x0
                floor_y = player.y + row_distance * ray_dir_y0

                for screen_x in range(0, SCREEN_WIDTH, 4):  # Increase step for performance
                    # Check for invalid coordinates
                    try:
                        if abs(floor_x) > 1e6 or abs(floor_y) > 1e6:
                            continue
                        cell_x = int(floor_x) % len(game_map[0])
                        cell_y = int(floor_y) % len(game_map)
                        
                        # Ceiling pattern (pure black with slight distance fade)
                        dist_fade = max(0.0, min(0.3, 1.0 / (abs(row_distance) * 0.4)))
                        checker = (cell_x + cell_y) % 2 == 0
                        if checker:
                            color = (int(0 * dist_fade), int(0 * dist_fade), int(0 * dist_fade))
                        else:
                            color = (int(10 * dist_fade), int(10 * dist_fade), int(10 * dist_fade))
                        
                        # Draw larger rectangles instead of individual pixels
                        rect_size = max(1, int(mode7_step * (1 + abs(row_distance) * 0.1)))
                        if screen_x + rect_size <= SCREEN_WIDTH and screen_y + rect_size <= ceiling_end:
                            pygame.draw.rect(screen, color, 
                                          (screen_x, screen_y, rect_size, rect_size))
                    except (OverflowError, ValueError):
                        continue  # Skip this pixel if coordinates are invalid
                        
                    floor_x += floor_step_x
                    floor_y += floor_step_y

            elif row_distance > 0 and state.settings['Mode7 Floor']['value']:
                # Draw floor
                floor_step_x = row_distance * (ray_dir_x1 - ray_dir_x0) / SCREEN_WIDTH
                floor_step_y = row_distance * (ray_dir_y1 - ray_dir_y0) / SCREEN_WIDTH

                floor_x = player.x + row_distance * ray_dir_x0
                floor_y = player.y + row_distance * ray_dir_y0

                for screen_x in range(0, SCREEN_WIDTH, 4):  # Increase step for performance
                    # Check for invalid coordinates
                    try:
                        if abs(floor_x) > 1e6 or abs(floor_y) > 1e6:
                            continue
                        cell_x = int(floor_x) % len(game_map[0])
                        cell_y = int(floor_y) % len(game_map)
                        
                        # Floor pattern (dark gray with slight distance fade)
                        dist_fade = max(0.3, min(0.8, 1.0 / (abs(row_distance) * 0.2)))
                        checker = (cell_x + cell_y) % 2 == 0
                        if checker:
                            color = (int(30 * dist_fade), int(30 * dist_fade), int(30 * dist_fade))
                        else:
                            color = (int(40 * dist_fade), int(40 * dist_fade), int(40 * dist_fade))
                        
                        # Draw larger rectangles instead of individual pixels
                        rect_size = max(1, int(mode7_step * (1 + abs(row_distance) * 0.1)))
                        if screen_x + rect_size <= SCREEN_WIDTH and screen_y >= floor_start:
                            pygame.draw.rect(screen, color, 
                                          (screen_x, screen_y, rect_size, rect_size))
                    except (OverflowError, ValueError):
                        continue  # Skip this pixel if coordinates are invalid
                        
                    floor_x += floor_step_x
                    floor_y += floor_step_y
    
    # Cast rays using quality settings
    fov = state.get_fov()
    half_fov = fov / 2
    quality = state.get_quality_settings()
    num_rays = quality['rays']
    
    for ray in range(num_rays):
        # Calculate ray angle
        ray_angle = (player.angle - half_fov) + (ray / RAYS) * fov
        
        # Initialize ray position
        ray_x = player.x
        ray_y = player.y
        
        # Step size for raycasting
        cos_a = math.cos(ray_angle)
        sin_a = math.sin(ray_angle)
        
        # Cast ray until we hit a wall
        for depth in range(MAX_DEPTH):
            ray_x += cos_a * 0.1
            ray_y += sin_a * 0.1
            
            # Get map square
            map_x = int(ray_x)
            map_y = int(ray_y)
            
            # Check if ray is out of bounds
            if map_x < 0 or map_x >= len(game_map[0]) or map_y < 0 or map_y >= len(game_map):
                break
                
            # Check if we hit a wall
            if game_map[map_y][map_x] == 1:
                # Calculate raw distance from player to wall hit
                dx = ray_x - player.x
                dy = ray_y - player.y
                raw_dist = math.sqrt(dx * dx + dy * dy)
                # Correct fish-eye by projecting distance onto camera direction
                perp_dist = raw_dist * math.cos(ray_angle - player.angle)
                # Avoid extremely small distances which blow up projection
                if perp_dist < 0.0001:
                    perp_dist = 0.0001
                
                # Optimized projection calculation
                proj = int((SCREEN_HEIGHT / perp_dist) * PROJECTION_SCALE)
                wall_height = min(SCREEN_HEIGHT * 2, proj)  # Cap maximum height

                if wall_height > MIN_WALL_HEIGHT:
                    # Calculate offsets with reduced multipliers
                    pitch_offset = int(player.pitch * SCREEN_HEIGHT * 0.3)
                    height_offset = int((player.z - 0.5) * SCREEN_HEIGHT * 0.2)
                    
                    # Optimized wall position calculation
                    half_height = wall_height // 2
                    center_y = SCREEN_HEIGHT // 2 + pitch_offset + height_offset
                    wall_top = center_y - half_height
                    wall_bottom = center_y + half_height
                    
                    # Fast bounds check
                    if wall_bottom > 0 and wall_top < SCREEN_HEIGHT:
                        wall_top = max(0, wall_top)
                        wall_bottom = min(SCREEN_HEIGHT, wall_bottom)
                        
                # Calculate wall normal for directional shading
                wall_normal = math.atan2(map_y + 0.5 - ray_y, map_x + 0.5 - ray_x)
                angle_diff = (wall_normal - player.angle) % (math.pi * 2)
                directional_shade = abs(math.cos(angle_diff)) * 0.6 + 0.4
                
                # Distance-based intensity
                dist_shade = max(0.2, min(1.0, 1.0 / (perp_dist * 0.2)))
                
                # Fog calculation
                fog_factor = min(1.0, max(0.0, (perp_dist - FOG_START) / (FOG_END - FOG_START)))
                
                # Get base color and apply all effects
                base_color = WALL_COLORS[(map_x + map_y) % 2]
                wall_color = []
                for i in range(3):
                    # Apply shading and fog
                    c = base_color[i] * dist_shade * directional_shade
                    c = c * (1 - fog_factor) + FOG_COLOR[i] * fog_factor
                    wall_color.append(int(min(255, max(0, c))))
                
                pygame.draw.rect(screen, tuple(wall_color),
                                      (ray * (SCREEN_WIDTH // num_rays), wall_top,
                                       (SCREEN_WIDTH // num_rays) + 1, wall_bottom - wall_top))
                break
    
    # Apply post-processing shader effects
    state.shader_time = pygame.time.get_ticks()
    screen = apply_shader_effects(screen, state.shader_time)
    
    # Show FPS
    if show_fps:
        fps_text = font.render(f'FPS: {int(clock.get_fps())}', True, (255, 255, 255))
        screen.blit(fps_text, (10, 10))
    
    # Draw menu overlay when paused
    if state.paused:
        # translucent overlay
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))

        if state.in_settings:
            # Draw settings panel
            for i, (name, setting) in enumerate(state.settings.items()):
                rect = get_menu_item_rect(i, name, is_settings=True)
                # background
                if i == state.selected_setting:
                    bg_color = (60, 60, 100, 220)
                else:
                    bg_color = (30, 30, 30, 180)
                pygame.draw.rect(overlay, bg_color, rect)

                # name
                name_surf = setting_font.render(name, True, MENU_FG)
                name_rect = name_surf.get_rect(midleft=(rect.left + 12, rect.centery))
                overlay.blit(name_surf, name_rect)

                # value
                if 'options' in setting:
                    val_text = setting['options'][int(setting['value'])]
                else:
                    # format float nicely
                    if isinstance(setting['value'], float):
                        val_text = f"{setting['value']:.3f}" if setting['value'] < 1 else f"{setting['value']:.2f}"
                    else:
                        val_text = str(setting['value'])
                val_surf = setting_font.render(val_text, True, MENU_SELECTED)
                val_rect = val_surf.get_rect(midright=(rect.right - 20, rect.centery))
                overlay.blit(val_surf, val_rect)

                # draw +/- hints
                minus = setting_font.render('-', True, MENU_FG)
                plus = setting_font.render('+', True, MENU_FG)
                overlay.blit(minus, (rect.right - 80, rect.centery - minus.get_height() // 2))
                overlay.blit(plus, (rect.right - 28, rect.centery - plus.get_height() // 2))
        else:
            # Draw menu option backgrounds and text onto overlay so the alpha blends
            for i, opt in enumerate(state.menu_options):
                rect = get_menu_item_rect(i, opt)
                # background color: highlight the selected option
                if i == state.selected_option:
                    bg_color = (80, 80, 120, 200)
                else:
                    bg_color = (40, 40, 40, 160)
                # draw rounded-ish rect (simple filled rect)
                pygame.draw.rect(overlay, bg_color, rect)
                # render text
                color = MENU_SELECTED if i == state.selected_option else MENU_FG
                text_surf = menu_font.render(opt, True, color)
                text_rect = text_surf.get_rect(center=rect.center)
                overlay.blit(text_surf, text_rect)

        # Blit the overlay with menus onto the screen
        screen.blit(overlay, (0, 0))

    # Update display
    pygame.display.flip()
    clock.tick(60)

# Quit game
pygame.quit()
