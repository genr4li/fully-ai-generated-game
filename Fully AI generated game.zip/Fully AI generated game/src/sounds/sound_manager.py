import os
import pygame

class SoundManager:
    def __init__(self):
        self.sounds = {}
        self._load_sounds()
        
    def _load_sounds(self):
        """Load all sound files from the sounds directory"""
        sound_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "sound")
        if not os.path.exists(sound_dir):
            os.makedirs(sound_dir)
            print(f"Created sounds directory at {sound_dir}")
            return
            
        for file in os.listdir(sound_dir):
            if file.endswith(".wav"):
                sound_path = os.path.join(sound_dir, file)
                sound_name = os.path.splitext(file)[0]
                try:
                    self.sounds[sound_name] = pygame.mixer.Sound(sound_path)
                except Exception as e:
                    print(f"Failed to load sound {sound_name}: {e}")
                    
    def play(self, sound_name):
        """Play a sound by name"""
        if sound_name in self.sounds:
            self.sounds[sound_name].play()
        else:
            print(f"Sound not found: {sound_name}")
            
    def stop_all(self):
        """Stop all playing sounds"""
        pygame.mixer.stop()
