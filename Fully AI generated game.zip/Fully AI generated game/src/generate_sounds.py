"""Sound generator for the raycaster game.
This script generates basic sound effects using synthesizer techniques.
"""

import os
import math
import wave
import struct
import random
import numpy as np

def ensure_dir(path):
    if not os.path.exists(path):
        os.makedirs(path)

def write_wav(filename, data, framerate=44100):
    """Write raw audio data to WAV file"""
    with wave.open(filename, 'w') as wav:
        # Configure WAV format (mono, 16-bit)
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(framerate)
        # Convert float samples to 16-bit integers and write
        wav.writeframes(struct.pack('h'*len(data),
                                  *[int(max(-32768, min(32767, sample * 32767)))
                                    for sample in data]))

def generate_shot():
    """Generate a gunshot sound effect"""
    duration = 0.2
    framerate = 44100
    t = np.linspace(0, duration, int(framerate * duration))
    
    # White noise burst with exponential decay
    noise = np.random.uniform(-1, 1, len(t))
    envelope = np.exp(-t * 30)
    
    # Add some low frequency content for "punch"
    bass = np.sin(2 * np.pi * 120 * t) * np.exp(-t * 50)
    
    # Combine and normalize
    sound = (noise * envelope * 0.7 + bass * 0.3) * 0.9
    return sound

def generate_footstep():
    """Generate a footstep sound effect"""
    duration = 0.15
    framerate = 44100
    t = np.linspace(0, duration, int(framerate * duration))
    
    # Create a dull thud with some noise
    base_freq = random.uniform(60, 100)
    thud = np.sin(2 * np.pi * base_freq * t) * np.exp(-t * 40)
    
    # Add some higher frequency content for "crunch"
    noise = np.random.uniform(-1, 1, len(t))
    noise_env = np.exp(-t * 60)
    
    # Combine and normalize
    sound = (thud * 0.7 + noise * noise_env * 0.3) * 0.7
    return sound

def generate_hit():
    """Generate a hit/impact sound effect"""
    duration = 0.1
    framerate = 44100
    t = np.linspace(0, duration, int(framerate * duration))
    
    # Sharp attack with quick decay
    freq = random.uniform(200, 400)
    impact = np.sin(2 * np.pi * freq * t) * np.exp(-t * 100)
    
    # Add some noise for texture
    noise = np.random.uniform(-1, 1, len(t))
    noise_env = np.exp(-t * 80)
    
    # Combine and normalize
    sound = (impact * 0.6 + noise * noise_env * 0.4) * 0.8
    return sound

def generate_pickup():
    """Generate a pickup/collect sound effect"""
    duration = 0.2
    framerate = 44100
    t = np.linspace(0, duration, int(framerate * duration))
    
    # Rising frequency sweep
    freq = 400 + 1000 * t
    sweep = np.sin(2 * np.pi * freq * t)
    
    # Add some sparkle
    sparkle = np.sin(2 * np.pi * 2000 * t) * np.exp(-t * 20)
    
    # Shape with envelope
    envelope = 1 - np.exp(-t * 30)
    
    # Combine and normalize
    sound = (sweep * 0.6 + sparkle * 0.4) * envelope * 0.7
    return sound

def main():
    # Create sound directory if it doesn't exist
    sound_dir = os.path.join(os.path.dirname(__file__), "sound")
    ensure_dir(sound_dir)
    
    # Generate and save all sound effects
    sounds = {
        'shot': generate_shot(),
        'footstep': generate_footstep(),
        'hit': generate_hit(),
        'pickup': generate_pickup()
    }
    
    # Write WAV files
    for name, data in sounds.items():
        filename = os.path.join(sound_dir, f"{name}.wav")
        write_wav(filename, data)
        print(f"Generated {filename}")

if __name__ == '__main__':
    main()
