"""Generate simple, royalty-free .wav sound effects for a raycaster game.

This script uses only the Python standard library (wave, struct, math, random)
and produces short effects: shot.wav, hit.wav, footstep.wav, pickup.wav.

Run from the folder that contains this script, for example:

    python generate_sounds.py

Output files are written into the same directory as this script.
"""
import wave
import struct
import math
import random
from pathlib import Path

SAMPLE_RATE = 44100


def write_wav(filename, samples, sample_rate=SAMPLE_RATE):
    # samples: iterable of floats in -1.0..1.0
    with wave.open(str(filename), 'wb') as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)  # 16-bit
        wf.setframerate(sample_rate)
        frames = b''.join(struct.pack('<h', int(max(-1.0, min(1.0, s)) * 32767)) for s in samples)
        wf.writeframes(frames)


def sine(freq, length, amp=1.0, sample_rate=SAMPLE_RATE):
    for n in range(int(length * sample_rate)):
        yield amp * math.sin(2 * math.pi * freq * (n / sample_rate))


def exp_decay(signal_iter, decay_rate=6.0, sample_rate=SAMPLE_RATE):
    # multiply the signal by e^{-t*decay_rate}
    for i, s in enumerate(signal_iter):
        t = i / sample_rate
        yield s * math.exp(-decay_rate * t)


def noise_burst(length, amp=1.0, sample_rate=SAMPLE_RATE):
    for _ in range(int(length * sample_rate)):
        yield (random.random() * 2 - 1) * amp


def lowpass(samples, cutoff=1200.0, sample_rate=SAMPLE_RATE):
    # simple one-pole lowpass filter
    rc = 1.0 / (2 * math.pi * cutoff)
    dt = 1.0 / sample_rate
    alpha = dt / (rc + dt)
    prev = 0.0
    for s in samples:
        prev = prev + alpha * (s - prev)
        yield prev


def make_shot():
    # Shot: noisy attack + short high harmonic, fast decay
    duration = 0.25
    # high squeal component
    squeal = sine(1800, duration, amp=0.6)
    # noisy blast
    blast = noise_burst(duration, amp=1.0)
    # mix with envelope
    mixed = (s + 0.6 * q for s, q in zip(blast, squeal))
    decayed = exp_decay(mixed, decay_rate=12.0)
    mellow = lowpass(decayed, cutoff=3500.0)
    return mellow


def make_hit():
    # Hit/thud: low sine burst with quick decay
    duration = 0.35
    base = sine(120, duration, amp=1.0)
    # add a few ms of higher harmonic
    harmonic = sine(350, duration, amp=0.25)
    mixed = (0.9 * b + 0.2 * h for b, h in zip(base, harmonic))
    decayed = exp_decay(mixed, decay_rate=8.0)
    mellow = lowpass(decayed, cutoff=1000.0)
    return mellow


def make_footstep():
    # Footstep: short filtered noise with quick envelope
    duration = 0.18
    n = noise_burst(duration, amp=1.0)
    # short decay and lower bandwidth
    dec = exp_decay(n, decay_rate=20.0)
    muffled = lowpass(dec, cutoff=1500.0)
    # small low thump underlay
    thump = sine(80, duration, amp=0.35)
    return (0.8 * m + 0.2 * t for m, t in zip(muffled, thump))


def make_pickup():
    # Pickup: short ascending sine sequence (pleasant UI ping)
    duration = 0.22
    # linear slide from 800Hz to 1600Hz
    length = int(duration * SAMPLE_RATE)
    for i in range(length):
        t = i / SAMPLE_RATE
        freq = 800 + (1600 - 800) * (i / length)
        amp = 0.9 * (1 - (i / length) * 0.6)
        yield amp * math.sin(2 * math.pi * freq * t)


def main():
    # Write generated .wav files into the repository-level `sound/` folder
    out_dir = Path(__file__).resolve().parent.parent / 'sound'
    out_dir.mkdir(parents=True, exist_ok=True)
    files = {
        'shot.wav': make_shot(),
        'hit.wav': make_hit(),
        'footstep.wav': make_footstep(),
        'pickup.wav': make_pickup(),
    }
    print('Generating sounds in', out_dir)
    for name, generator in files.items():
        path = out_dir / name
        # Convert generator to list (small durations, memory ok)
        samples = list(generator)
        write_wav(path, samples)
        print('  wrote', path.name, f'({len(samples)/SAMPLE_RATE:.2f}s)')


if __name__ == '__main__':
    main()
