"""
Simple pygame sound manager for loading and playing generated .wav files.
Usage:
    from sounds.sound_manager import SoundManager
    sm = SoundManager()
    sm.init()  # initializes pygame.mixer
    sm.load_sounds('.')
    sm.play('shot')

This keeps sound logic separated from the main game loop.
"""
from pathlib import Path
import pygame
import os


class SoundManager:
    def __init__(self):
        self.sounds = {}
        self.initialized = False

    def init(self, freq=44100, size=-16, channels=1, buffer=512):
        if not self.initialized:
            pygame.mixer.pre_init(freq, size, channels, buffer)
            pygame.init()
            self.initialized = True

    def load_sounds(self, folder_path):
        path = Path(folder_path)
        if not path.exists():
            raise FileNotFoundError(f"Sound folder not found: {path}")
        for fname in os.listdir(path):
            if fname.lower().endswith('.wav'):
                key = Path(fname).stem
                full = str(path / fname)
                try:
                    self.sounds[key] = pygame.mixer.Sound(full)
                except Exception as e:
                    print('Failed to load', full, e)

    def play(self, name, volume=1.0):
        snd = self.sounds.get(name)
        if not snd:
            print('Sound not found:', name)
            return
        snd.set_volume(volume)
        snd.play()

    def stop(self, name=None):
        if name is None:
            pygame.mixer.stop()
        else:
            snd = self.sounds.get(name)
            if snd:
                snd.stop()
