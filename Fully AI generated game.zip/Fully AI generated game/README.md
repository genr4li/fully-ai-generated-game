# Raycaster Game

A Python-based raycaster game with sound effects. This project includes a custom sound generation system and pygame-based game engine.

## Files

- generate_sounds.py  - programmatically generates 4 .wav sounds (shot, hit, footstep, pickup).
- sound_manager.py    - small helper to initialize mixer, load .wav files and play them.

How to generate the .wav files

1. Open PowerShell and change to the project folder (if needed):

   cd "C:\Users\JM17199\OneDrive - Williamsburg-James City County Public Schools\Fully AI generated game"

2. Run the generator script:

   python "generate_sounds.py"

You should see output like:

  Generating sounds in C:\...\Fully AI generated game
    wrote shot.wav (0.25s)
    wrote hit.wav (0.35s)
    wrote footstep.wav (0.18s)
    wrote pickup.wav (0.22s)

How to integrate into `raycaster.py`

1. Import and initialize the sound manager early in your main script (after pygame initialization):

   from sound_manager import SoundManager
   sm = SoundManager()
   sm.init()
   sm.load_sounds('.')  # load sounds from the same folder

2. Play sounds where appropriate, for example when firing or hitting:

   sm.play('shot')
   sm.play('hit')
   sm.play('footstep')
   sm.play('pickup')

Notes

- These sounds are programmatically generated and royalty-free.
- If you want different or higher-quality sounds, replace the generated .wav files with your own WAVs (CC0 or licensed).
